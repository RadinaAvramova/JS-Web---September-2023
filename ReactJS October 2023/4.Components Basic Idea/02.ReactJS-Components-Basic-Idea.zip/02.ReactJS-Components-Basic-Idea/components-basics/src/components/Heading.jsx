export default function Heading(props) {
    return (
        <h2 className="site-header">{props.children}</h2>
    );
}