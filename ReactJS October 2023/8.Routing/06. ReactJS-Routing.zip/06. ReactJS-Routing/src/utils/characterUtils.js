export const normalizeName = (name) => name.replace(/ /g, '-').toLowerCase(); 
