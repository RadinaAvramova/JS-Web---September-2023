const Mission = () => {
    return (
        <>
            <h3>Our Mission</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatem fugit, mollitia reiciendis eos vero magni esse excepturi perspiciatis odit dicta sed itaque eius velit similique illo rem. Assumenda quae quis nesciunt libero itaque corrupti sapiente? Quia odit at iste culpa sunt minus commodi iusto nihil fugit? Velit incidunt corporis quam.</p>
        </>
    );
}

export default Mission;
